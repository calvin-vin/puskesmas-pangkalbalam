Dokter
username:sutan123@gmail.com
password:sutan123

Petugas pendaftaran
username:davidkun11@gmail.com
password:david123

Petugas rujukan
username:mrirpan@gmail.com
password:irpan123

Petugas lab
username:vennodesh@gmail.com
password:venno123

Admin puskesmas
username:kristiaella@gmail.com
password:ella123

Admin
username:khailasrakh@gmail.com
password:khailas123

1cUf2y3WniW4

